export interface Profile {
    id: string;
    username: string;
    bio: string;
    imagePath: string;
    creator: string;
  }
  